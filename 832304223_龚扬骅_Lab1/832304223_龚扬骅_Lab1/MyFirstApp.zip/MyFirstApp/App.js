import React, { useState } from 'react';
import { View, Text, Image, Button, TextInput, StyleSheet, SafeAreaView } from 'react-native';
import Constants from 'expo-constants';

export default function App() {
  const [displayText, setDisplayText] = useState("Welcome to My React Native App");
  const [username, setUsername] = useState("");
  const [greeting, setGreeting] = useState("");

  const handleButtonPress = () => {
    setDisplayText("You clicked the button! Enjoy your app 😊");
    if (username.trim()) {
      setGreeting(`Hello, ${username}! Nice to meet you 👋`);
    } else {
      setGreeting("Please enter your name first!");
    }
  };

  return (
      <SafeAreaView style={styles.container}>
        <View style={styles.contentWrapper}>
          <Text style={styles.titleText}>{displayText}</Text>

          <TextInput
              style={styles.nameInput}
              placeholder="Enter your name here"
              value={username}
              onChangeText={(inputText) => setUsername(inputText)}
              autoCapitalize="words"
              autoCorrect={false}
              keyboardType="default"
          />

          {greeting ? (
              <Text style={styles.greetingText}>{greeting}</Text>
          ) : null}

          <Image
              style={styles.appImage}
              source={{ uri: "https://picsum.photos/400/300?nature" }}
              resizeMode="contain"
              accessibilityLabel="Scenic landscape"
          />

          <Button
              title="Click Me!"
              onPress={handleButtonPress}
              color="#2196F3"
              accessibilityLabel="Change text button"
          />
        </View>
      </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f8f9fa",
    paddingTop: Constants.statusBarHeight,
  },
  contentWrapper: {
    flex: 1,
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 20,
  },
  titleText: {
    fontSize: 22,
    fontWeight: "600",
    color: "#2d3436",
    marginBottom: 20,
    textAlign: "center",
  },
  nameInput: {
    width: "100%",
    height: 48,
    backgroundColor: "#fff",
    borderColor: "#ced4da",
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 16,
    marginBottom: 15,
    fontSize: 16,
    color: "#2d3436",
  },
  greetingText: {
    fontSize: 18,
    color: "#2196F3",
    marginBottom: 30,
    textAlign: "center",
    fontWeight: "500",
  },
  appImage: {
    width: 320,
    height: 220,
    marginBottom: 30,
    borderRadius: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
});