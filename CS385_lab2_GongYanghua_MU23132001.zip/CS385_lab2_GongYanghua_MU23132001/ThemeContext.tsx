import React, { createContext, useState, useContext, ReactNode, useEffect } from 'react';
import { useColorScheme } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

// 定义主题模式的类型
type ThemeMode = 'light' | 'dark' | 'system' | 'time';

interface ThemeContextType {
  // isDarkMode 仍然是最终的主题状态 (true 代表深色)
  isDarkMode: boolean; 
  // themeMode 是用户选择的模式
  themeMode: ThemeMode;
  // 用于更改用户选择的模式
  setThemeMode: (mode: ThemeMode) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

const THEME_STORAGE_KEY = '@theme_mode';

export const ThemeProvider = ({ children }: { children: ReactNode }) => {
  const systemScheme = useColorScheme();
  const [themeMode, setThemeModeState] = useState<ThemeMode>('system');

  // 在应用加载时，从 AsyncStorage 读取保存的设置
  useEffect(() => {
    const loadTheme = async () => {
      try {
        const savedMode = await AsyncStorage.getItem(THEME_STORAGE_KEY) as ThemeMode | null;
        if (savedMode) {
          setThemeModeState(savedMode);
        }
      } catch (e) {
        console.error('Failed to load theme from storage.', e);
      }
    };
    loadTheme();
  }, []);

  // 用于更新主题模式并保存到 AsyncStorage
  const setThemeMode = async (mode: ThemeMode) => {
    try {
      await AsyncStorage.setItem(THEME_STORAGE_KEY, mode);
      setThemeModeState(mode);
    } catch (e) {
      console.error('Failed to save theme to storage.', e);
    }
  };

  // 根据用户选择的模式 (themeMode) 计算出最终的 isDarkMode
  let isDarkMode: boolean;
  switch (themeMode) {
    case 'light':
      isDarkMode = false;
      break;
    case 'dark':
      isDarkMode = true;
      break;
    case 'time':
      // 简单实现：早上6点到晚上6点为浅色，其余为深色
      // 真实的日出日落需要地理位置权限，这里做简化
      const currentHour = new Date().getHours();
      isDarkMode = currentHour < 6 || currentHour >= 18;
      break;
    case 'system':
    default:
      isDarkMode = systemScheme === 'dark';
      break;
  }

  return (
    <ThemeContext.Provider value={{ isDarkMode, themeMode, setThemeMode }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};