import React from 'react';
import { View, Text, Button, StyleSheet, Pressable, Alert } from 'react-native'; // <-- 1. 导入 Alert
import { useRouter, useNavigation } from 'expo-router';
import { DrawerActions } from '@react-navigation/native';
import { useAuth } from '../../../context/AuthContext';
import { useTheme } from '../../../context/ThemeContext';
import { useTranslation } from 'react-i18next';
import { FontAwesome } from '@expo/vector-icons';

export default function MePage() {
  const { user, logout } = useAuth();
  const { t } = useTranslation();
  const router = useRouter();
  const navigation = useNavigation();
  const { isDarkMode } = useTheme();

  React.useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <Pressable onPress={() => navigation.dispatch(DrawerActions.openDrawer())}>
          <FontAwesome name="bars" size={24} color={isDarkMode ? 'white' : 'black'} style={{ marginRight: 15 }} />
        </Pressable>
      ),
    });
  }, [navigation, isDarkMode]);

  // 2. 创建一个新的 handleLogout 函数
  const handleLogout = () => {
    Alert.alert(
      "Logged Out", // 弹窗标题
      "You have successfully logged out.", // 弹窗消息
      [
        {
          text: "OK",
          // 只有当用户点击 "OK" 后，才真正执行 logout()
          onPress: () => logout(),
        },
      ]
    );
  };

  const theme = {
    container: { backgroundColor: isDarkMode ? '#000' : '#f0f0f0' },
    text: { color: isDarkMode ? '#fff' : '#000' },
  };

  return (
    <View style={[styles.container, theme.container]}>
      {user ? (
        <>
          <Text style={[styles.text, theme.text]}>{t('welcome')}, {user.username}!</Text>
          {/* 3. 让按钮调用新的 handleLogout 函数 */}
          <Button title={t('logout')} onPress={handleLogout} />
        </>
      ) : (
        <>
          <Text style={[styles.text, theme.text]}>{t('notLoggedIn')}</Text>
          <View style={styles.buttonContainer}>
            <Button title={t('login')} onPress={() => router.push('/login')} />
            <Button title={t('register')} onPress={() => router.push('/register')} />
          </View>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  text: { fontSize: 20, marginBottom: 20 },
  buttonContainer: { flexDirection: 'row', width: '60%', justifyContent: 'space-around' },
});