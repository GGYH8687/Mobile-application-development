import React from 'react';
import { View, Text, StyleSheet, Button, Pressable } from 'react-native';
import { useTheme } from '../../context/ThemeContext';
import { useTranslation } from 'react-i18next';

type ThemeMode = 'light' | 'dark' | 'system' | 'time';

export default function SettingsPage() {
  const { themeMode, setThemeMode, isDarkMode } = useTheme();
  const { t, i18n } = useTranslation();

  const themeOptions: { labelKey: string; mode: ThemeMode }[] = [
    { labelKey: 'lightMode', mode: 'light' },
    { labelKey: 'darkMode', mode: 'dark' },
    { labelKey: 'followSystem', mode: 'system' },
    { labelKey: 'autoTime', mode: 'time' },
  ];

  const theme = {
    container: { backgroundColor: isDarkMode ? '#000' : '#f5f5f5' },
    text: { color: isDarkMode ? '#fff' : '#000' },
    option: { borderColor: isDarkMode ? '#555' : '#ccc' },
    activeText: { color: '#fff' },
  };

  return (
    <View style={[styles.container, theme.container]}>
      <View style={styles.section}>
        <Text style={[styles.title, theme.text]}>{t('languageSettings')}</Text>
        <View style={styles.buttonContainer}>
          <Button title="English" onPress={() => i18n.changeLanguage('en')} />
          <Button title="中文" onPress={() => i18n.changeLanguage('zh')} />
        </View>
      </View>
      <View style={styles.section}>
        <Text style={[styles.title, theme.text]}>{t('themeSettings')}</Text>
        <View>
          {themeOptions.map(opt => (
            <Pressable
              key={opt.mode}
              style={[ styles.optionButton, theme.option, themeMode === opt.mode && styles.activeOption ]}
              onPress={() => setThemeMode(opt.mode)}
            >
              <Text style={[theme.text, themeMode === opt.mode && theme.activeText]}>{t(opt.labelKey)}</Text>
            </Pressable>
          ))}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  section: { marginBottom: 30 },
  title: { fontSize: 22, fontWeight: 'bold', marginBottom: 15 },
  buttonContainer: { flexDirection: 'row', justifyContent: 'space-around' },
  optionButton: { borderWidth: 1, borderRadius: 8, paddingVertical: 12, marginBottom: 10, alignItems: 'center' },
  activeOption: { backgroundColor: '#007AFF', borderColor: '#007AFF' },
});