import { Stack } from 'expo-router';
import { AuthProvider } from '../context/AuthContext';
import { ThemeProvider } from '../context/ThemeContext';
import { I18nProvider } from '../context/I18nContext'; 

export default function RootLayout() {
  return (
    // 1. AuthProvider
    <AuthProvider>
      {/* 2. ThemeProvider */}
      <ThemeProvider>
        {/* 3. I18nProvider */}
        <I18nProvider>
          <Stack>
            <Stack.Screen name="(drawer)" options={{ headerShown: false }} />
            <Stack.Screen name="login" options={{ presentation: 'modal', title: 'Login' }} />
            <Stack.Screen name="register" options={{ presentation: 'modal', title: 'Register' }} />
          </Stack>
        </I18nProvider>
      </ThemeProvider>
    </AuthProvider>
  );
}